create table t (x timestamp not null);
