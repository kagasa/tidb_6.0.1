create table a (c int);
