INSERT INTO t_auto_random (id, c) VALUES
(1, 'normal_pk_01');
INSERT INTO t_auto_random VALUES
(NULL, 'null_pk_02');
INSERT INTO t_auto_random VALUES
(NULL, 'null_pk_03');
INSERT INTO t_auto_random (id, c) VALUES
(4, 'normal_pk_04');
