CREATE TABLE t_auto_random (
id bigint PRIMARY KEY AUTO_RANDOM(3),
c char(40) NOT NULL DEFAULT '');
