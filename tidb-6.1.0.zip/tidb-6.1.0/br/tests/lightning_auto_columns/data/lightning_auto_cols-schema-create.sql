create schema lightning_auto_cols;
