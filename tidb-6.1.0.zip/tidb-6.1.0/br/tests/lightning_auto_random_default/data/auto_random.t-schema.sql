/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `t` (
  `id` bigint unsigned primary key clustered auto_random,
  `s` varchar(32)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
