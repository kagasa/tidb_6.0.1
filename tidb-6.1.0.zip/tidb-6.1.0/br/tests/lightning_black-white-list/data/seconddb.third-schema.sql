create table `third` (id int primary key);
