/*!40103 SET TIME_ZONE='+00:00' */;
CREATE TABLE `t` (
  `id` bigint primary key clustered auto_random
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
