create table t (a int);
