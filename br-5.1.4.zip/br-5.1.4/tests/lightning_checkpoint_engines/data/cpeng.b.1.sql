insert into b values (10),(11),(12);
/*
padding to make the data file > 50 bytes
*/