insert into b values (13);
