create table empty_strings (
    id int,
    a varchar(20),
    b varchar(20)
);
