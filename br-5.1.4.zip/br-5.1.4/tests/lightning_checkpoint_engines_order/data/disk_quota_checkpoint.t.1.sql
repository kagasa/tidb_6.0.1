insert into t values
(4, 'four'),
(5, 'five'),
(6, 'six');
