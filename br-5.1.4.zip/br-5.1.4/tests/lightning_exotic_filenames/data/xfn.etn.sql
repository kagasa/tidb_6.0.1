insert `exotic``table````name` (a, b, _tidb_rowid) values
('aaaaaa', 11, 79995),
('bbbbbb', 22, 79996);
insert `exotic``table````name` (a, b, _tidb_rowid) values
('cccccc', 33, 79997),
('dddddd', 44, 79998),
('eeeeee', 55, 79999);
