create table 中文表(a int primary key);
