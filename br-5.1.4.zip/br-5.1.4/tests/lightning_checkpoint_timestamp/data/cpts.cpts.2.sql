insert into cpts values (), (), (), (), (), (), (), (), (), (), (), (), (), ();
insert into cpts values (), (), (), (), (), (), (), (), (), (), (), (), (), ();
insert into cpts values (), (), (), (), (), (), (), (), (), (), (), (), (), ();
