create database cpts;
