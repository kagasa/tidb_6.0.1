INSERT INTO b (id, k) VALUES (11, 13), (17, 19);
