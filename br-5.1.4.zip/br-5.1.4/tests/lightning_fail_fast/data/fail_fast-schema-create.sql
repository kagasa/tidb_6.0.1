CREATE DATABASE `fail_fast`;
