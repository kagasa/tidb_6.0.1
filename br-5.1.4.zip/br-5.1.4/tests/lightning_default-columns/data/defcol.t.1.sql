INSERT INTO t () VALUES (), (), (), (), (), ();
