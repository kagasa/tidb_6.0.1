create database seconddb;
