create table `testtable` (a int primary key);
