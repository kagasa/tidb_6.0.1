Reparo is a TiDB binlog recovery tool which is named from Harry Potter, a famous fiction by J. K. Rowling.
