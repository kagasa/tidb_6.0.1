create table cpts (ts datetime(6) not null default current_timestamp(6), key(ts));
