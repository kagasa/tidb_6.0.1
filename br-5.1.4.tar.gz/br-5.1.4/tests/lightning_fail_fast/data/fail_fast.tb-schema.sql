CREATE TABLE `tb` (id int, s1 varchar(16), s2 varchar(16), primary key (id), unique key uq (s1, s2));
