insert into t values ('1111-11-11 11:11:11');
