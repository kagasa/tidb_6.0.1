INSERT INTO t VALUES (), (), ();
