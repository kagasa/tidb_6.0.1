insert into expr_index (id, a, b) values (1, 'aaa', 'bbb'), (2, 'ABC', 'CDSFDS');
