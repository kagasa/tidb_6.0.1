create schema disk_quota_checkpoint;
