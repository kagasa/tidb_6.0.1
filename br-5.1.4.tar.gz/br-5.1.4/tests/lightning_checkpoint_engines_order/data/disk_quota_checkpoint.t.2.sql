insert into t values
(7, 'seven'),
(8, 'eight'),
(9, 'nine');
