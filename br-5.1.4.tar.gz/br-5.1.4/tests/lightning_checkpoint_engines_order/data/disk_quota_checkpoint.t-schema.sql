create table t (
    a int not null primary key,
    b varchar(10) unique
);
