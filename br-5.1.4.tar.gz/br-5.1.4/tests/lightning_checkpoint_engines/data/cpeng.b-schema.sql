create table b (c int);
