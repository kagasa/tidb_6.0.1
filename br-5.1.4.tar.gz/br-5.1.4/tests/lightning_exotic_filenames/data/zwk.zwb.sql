insert into 中文表 values (2345);
