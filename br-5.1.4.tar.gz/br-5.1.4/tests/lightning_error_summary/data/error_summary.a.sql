INSERT INTO a (id, k) VALUES (2, 3), (5, 7);
