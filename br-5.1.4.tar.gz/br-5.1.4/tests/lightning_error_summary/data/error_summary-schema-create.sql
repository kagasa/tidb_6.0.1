CREATE DATABASE error_summary;
