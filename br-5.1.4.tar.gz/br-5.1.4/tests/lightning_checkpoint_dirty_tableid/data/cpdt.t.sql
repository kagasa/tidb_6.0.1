insert into t values ('1999-09-09 09:09:09');
