create database cpdt;
