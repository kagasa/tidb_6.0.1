create table `second` (id int primary key);
