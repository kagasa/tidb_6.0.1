create database firstdb;
