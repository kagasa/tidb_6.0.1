create table `first` (id int primary key);
