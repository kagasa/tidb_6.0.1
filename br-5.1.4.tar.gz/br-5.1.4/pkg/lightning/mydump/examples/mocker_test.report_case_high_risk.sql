INSERT INTO `report_case_high_risk` VALUES (2,'4','6',8,10);
