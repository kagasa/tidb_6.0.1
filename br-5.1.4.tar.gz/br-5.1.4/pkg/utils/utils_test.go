// Copyright 2020 PingCAP, Inc. Licensed under Apache-2.0.

package utils

import (
	"testing"

	. "github.com/pingcap/check"
)

func TestT(t *testing.T) {
	TestingT(t)
}
