/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `t` (`s`) VALUES
("test1"),
("test2"),
("test3");
